declare module 'debug'
