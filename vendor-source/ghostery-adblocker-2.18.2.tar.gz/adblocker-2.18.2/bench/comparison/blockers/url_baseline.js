/*!
 * Copyright (c) 2017-present Ghostery GmbH. All rights reserved.
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */

import { URL } from 'node:url';

export default class Url {
  static parse() {
    return new Url();
  }

  match({ url, frameUrl }) {
    new URL(url);
    return new URL(frameUrl);
  }
}
