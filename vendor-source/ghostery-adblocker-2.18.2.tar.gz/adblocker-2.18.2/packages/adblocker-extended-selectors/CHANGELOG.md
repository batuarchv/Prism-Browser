# v2.18.2 (Wed Aug 05 2026)

#### :bug: Bug Fix

- Run linters ([@seia-soto](https://github.com/seia-soto))
- Upgrade dependencies ([@seia-soto](https://github.com/seia-soto))

#### :memo: Documentation

- fix(docs): closing tag mismatches [#5782](https://github.com/ghostery/adblocker/pull/5782) ([@seia-soto](https://github.com/seia-soto))

#### :nut_and_bolt: Dependencies

- Upgrade dependencies [#5776](https://github.com/ghostery/adblocker/pull/5776) ([@seia-soto](https://github.com/seia-soto))

#### Authors: 1

- HoJeong Go ([@seia-soto](https://github.com/seia-soto))

---

# v2.18.1 (Wed Jul 01 2026)

#### :house: Internal

- internal: housekeeping with 2026 asset registration [#5740](https://github.com/ghostery/adblocker/pull/5740) ([@seia-soto](https://github.com/seia-soto))

#### Authors: 1

- HoJeong Go ([@seia-soto](https://github.com/seia-soto))

---

# v2.18.0 (Thu Jun 04 2026)

#### :running_woman: Performance

- perf: unnecessary `querySelectorAll('*')` [#5715](https://github.com/ghostery/adblocker/pull/5715) ([@seia-soto](https://github.com/seia-soto) [@philipp-classen](https://github.com/philipp-classen))

#### :house: Internal

- chore: update dependencies [#5723](https://github.com/ghostery/adblocker/pull/5723) ([@seia-soto](https://github.com/seia-soto))

#### :nut_and_bolt: Dependencies

- Build(deps-dev): Bump the development-dependencies group across 1 directory with 4 updates [#5701](https://github.com/ghostery/adblocker/pull/5701) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 3

- [@dependabot[bot]](https://github.com/dependabot[bot])
- HoJeong Go ([@seia-soto](https://github.com/seia-soto))
- Philipp Claßen ([@philipp-classen](https://github.com/philipp-classen))

---

# v2.17.2 (Tue May 19 2026)

#### :nut_and_bolt: Dependencies

- Build(deps-dev): Bump the development-dependencies group across 1 directory with 5 updates [#5692](https://github.com/ghostery/adblocker/pull/5692) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v2.17.1 (Thu May 14 2026)

#### :nut_and_bolt: Dependencies

- Build(deps): Bump the production-dependencies group with 2 updates [#5678](https://github.com/ghostery/adblocker/pull/5678) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v2.17.0 (Fri May 08 2026)

#### :nut_and_bolt: Dependencies

- Update dependencies [#5665](https://github.com/ghostery/adblocker/pull/5665) ([@seia-soto](https://github.com/seia-soto))
- Build(deps): Bump @types/node from 25.6.0 to 25.6.2 [#5660](https://github.com/ghostery/adblocker/pull/5660) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 2

- [@dependabot[bot]](https://github.com/dependabot[bot])
- HoJeong Go ([@seia-soto](https://github.com/seia-soto))

---

# v2.16.0 (Fri May 08 2026)

#### :house: Internal

- ci: migrate to node26 and update dependencies [#5654](https://github.com/ghostery/adblocker/pull/5654) ([@seia-soto](https://github.com/seia-soto))

#### Authors: 1

- HoJeong Go ([@seia-soto](https://github.com/seia-soto))

---

# v2.14.5 (Mon May 04 2026)

#### :bug: Bug Fix

- fix(extended-selectors): invalid regex handling [#5633](https://github.com/ghostery/adblocker/pull/5633) ([@seia-soto](https://github.com/seia-soto))

#### Authors: 1

- HoJeong Go ([@seia-soto](https://github.com/seia-soto))

---

# v2.14.2 (Mon Apr 27 2026)

#### ⚠️ Pushed to `master`

- fix(lint): refactor to fix `no-useless-assignment` ([@seia-soto](https://github.com/seia-soto))
- Update dependencies ([@seia-soto](https://github.com/seia-soto))

#### :house: Internal

- internal: retire nodejs v20 [#5582](https://github.com/ghostery/adblocker/pull/5582) ([@seia-soto](https://github.com/seia-soto))
- internal: TypeScript 6.0 migration [#5546](https://github.com/ghostery/adblocker/pull/5546) ([@seia-soto](https://github.com/seia-soto))
- Housekeeping [#5518](https://github.com/ghostery/adblocker/pull/5518) ([@seia-soto](https://github.com/seia-soto))

#### :nut_and_bolt: Dependencies

- Update dependencies [#5619](https://github.com/ghostery/adblocker/pull/5619) ([@seia-soto](https://github.com/seia-soto))
- Build(deps): Bump @types/node from 25.5.2 to 25.6.0 [#5592](https://github.com/ghostery/adblocker/pull/5592) ([@dependabot[bot]](https://github.com/dependabot[bot]))
- Build(deps-dev): Bump tshy from 3.3.2 to 4.0.0 [#5551](https://github.com/ghostery/adblocker/pull/5551) ([@dependabot[bot]](https://github.com/dependabot[bot]))
- Build(deps): Bump @types/node from 25.3.2 to 25.3.3 [#5497](https://github.com/ghostery/adblocker/pull/5497) ([@dependabot[bot]](https://github.com/dependabot[bot]))
- Build(deps): Bump @types/node from 25.3.0 to 25.3.2 [#5494](https://github.com/ghostery/adblocker/pull/5494) ([@dependabot[bot]](https://github.com/dependabot[bot]))
- Build(deps-dev): Bump nyc from 17.1.0 to 18.0.0 [#5489](https://github.com/ghostery/adblocker/pull/5489) ([@dependabot[bot]](https://github.com/dependabot[bot]))
- Update dependencies [#5486](https://github.com/ghostery/adblocker/pull/5486) ([@seia-soto](https://github.com/seia-soto))
- Build(deps): Bump @types/node from 25.2.3 to 25.3.0 [#5474](https://github.com/ghostery/adblocker/pull/5474) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 2

- [@dependabot[bot]](https://github.com/dependabot[bot])
- HoJeong Go ([@seia-soto](https://github.com/seia-soto))

---

# v2.14.0 (Thu Feb 12 2026)

#### :rocket: New Feature

- feat: pseudo directives with `:remove` [#5397](https://github.com/ghostery/adblocker/pull/5397) ([@seia-soto](https://github.com/seia-soto))

#### :nut_and_bolt: Dependencies

- chore: update dependencies [#5455](https://github.com/ghostery/adblocker/pull/5455) ([@seia-soto](https://github.com/seia-soto))
- Build(deps-dev): Bump eslint from 9.39.2 to 10.0.0 [#5448](https://github.com/ghostery/adblocker/pull/5448) ([@dependabot[bot]](https://github.com/dependabot[bot]))
- Build(deps): Bump @types/node from 25.1.0 to 25.2.1 [#5437](https://github.com/ghostery/adblocker/pull/5437) ([@dependabot[bot]](https://github.com/dependabot[bot]))
- Update dependencies [#5422](https://github.com/ghostery/adblocker/pull/5422) ([@seia-soto](https://github.com/seia-soto))
- Update dependencies [#5399](https://github.com/ghostery/adblocker/pull/5399) ([@seia-soto](https://github.com/seia-soto))

#### Authors: 2

- [@dependabot[bot]](https://github.com/dependabot[bot])
- HoJeong Go ([@seia-soto](https://github.com/seia-soto))

---

# v2.13.3 (Fri Jan 09 2026)

#### :bug: Bug Fix

- perf: delegation check for pseudo selector and reusible xpath expressions [#5382](https://github.com/ghostery/adblocker/pull/5382) ([@seia-soto](https://github.com/seia-soto))

#### Authors: 1

- HoJeong Go ([@seia-soto](https://github.com/seia-soto))

---

# v2.13.0 (Thu Dec 04 2025)

#### :nut_and_bolt: Dependencies

- chore(internal): update dependencies [#5323](https://github.com/ghostery/adblocker/pull/5323) ([@seia-soto](https://github.com/seia-soto))

#### Authors: 1

- HoJeong Go ([@seia-soto](https://github.com/seia-soto))

---

# v2.12.1 (Fri Oct 03 2025)

#### :nail_care: Polish

- chore(internal): update dependencies and replace node 18 with 24 [#5220](https://github.com/ghostery/adblocker/pull/5220) ([@seia-soto](https://github.com/seia-soto))

#### Authors: 1

- HoJeong Go ([@seia-soto](https://github.com/seia-soto))

---

# v2.11.5 (Thu Aug 21 2025)

#### :nut_and_bolt: Dependencies

- Update dependencies [#5120](https://github.com/ghostery/adblocker/pull/5120) ([@seia-soto](https://github.com/seia-soto))

#### Authors: 1

- HoJeong Go ([@seia-soto](https://github.com/seia-soto))

---

# v2.11.4 (Wed Aug 20 2025)

#### :house: Internal

- chore(internal): use `@ts-expect-error` directive instead [#5025](https://github.com/ghostery/adblocker/pull/5025) ([@seia-soto](https://github.com/seia-soto))

#### Authors: 1

- HoJeong Go ([@seia-soto](https://github.com/seia-soto))

---

# v2.11.2 (Thu Jul 17 2025)

#### :nut_and_bolt: Dependencies

- chore(internal): update `playwright` ecosystem [#5038](https://github.com/ghostery/adblocker/pull/5038) ([@seia-soto](https://github.com/seia-soto))

#### Authors: 1

- HoJeong Go ([@seia-soto](https://github.com/seia-soto))

---

# v2.11.0 (Wed Jul 09 2025)

#### :rocket: New Feature

- Extended selectors: xpath [#4933](https://github.com/ghostery/adblocker/pull/4933) ([@chrmod](https://github.com/chrmod))

#### Authors: 1

- Krzysztof Modras ([@chrmod](https://github.com/chrmod))

---

# v2.10.0 (Wed Jul 09 2025)

#### :rocket: New Feature

- Support :has natively [#5014](https://github.com/ghostery/adblocker/pull/5014) ([@chrmod](https://github.com/chrmod))

#### Authors: 1

- Krzysztof Modras ([@chrmod](https://github.com/chrmod))

---

# v2.9.5 (Mon Jul 07 2025)

#### :bug: Bug Fix

- fix(adblocker-extended-selector): `compound` with `complex` [#4974](https://github.com/ghostery/adblocker/pull/4974) ([@seia-soto](https://github.com/seia-soto) [@chrmod](https://github.com/chrmod))

#### Authors: 2

- HoJeong Go ([@seia-soto](https://github.com/seia-soto))
- Krzysztof Modras ([@chrmod](https://github.com/chrmod))

---

# v2.9.0 (Wed Jul 02 2025)

#### :rocket: New Feature

- Extended selectors: matches-css [#4932](https://github.com/ghostery/adblocker/pull/4932) (ghostery-adblocker-bot@users.noreply.github.com [@chrmod](https://github.com/chrmod))

#### :house: Internal

- Extended selectors: remove support for :if [#4968](https://github.com/ghostery/adblocker/pull/4968) ([@chrmod](https://github.com/chrmod))

#### Authors: 2

- Ghostery Adblocker Bot (ghostery-adblocker-bot@users.noreply.github.com)
- Krzysztof Modras ([@chrmod](https://github.com/chrmod))

---

# v2.8.0 (Mon Jun 23 2025)

#### :rocket: New Feature

- New extended selectors: matches-attr, matches-path, upward [#4931](https://github.com/ghostery/adblocker/pull/4931) ([@chrmod](https://github.com/chrmod) [@seia-soto](https://github.com/seia-soto))

#### :nut_and_bolt: Dependencies

- Build(deps-dev): Bump @types/node from 22.15.30 to 24.0.1 [#4939](https://github.com/ghostery/adblocker/pull/4939) ([@dependabot[bot]](https://github.com/dependabot[bot]) [@seia-soto](https://github.com/seia-soto))

#### Authors: 3

- [@dependabot[bot]](https://github.com/dependabot[bot])
- HoJeong Go ([@seia-soto](https://github.com/seia-soto))
- Krzysztof Modras ([@chrmod](https://github.com/chrmod))

---

# v2.3.2 (Thu Jan 23 2025)

#### :bug: Bug Fix

- Build(deps-dev): Bump jsdom from 25.0.1 to 26.0.0 ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### :nut_and_bolt: Dependencies

- Build(deps-dev): Bump typescript from 5.7.2 to 5.7.3 [#4583](https://github.com/ghostery/adblocker/pull/4583) ([@dependabot[bot]](https://github.com/dependabot[bot]))
- Build(deps-dev): Bump @types/chrome from 0.0.290 to 0.0.293 [#4582](https://github.com/ghostery/adblocker/pull/4582) ([@dependabot[bot]](https://github.com/dependabot[bot]))
- Build(deps-dev): Bump jsdom from 25.0.1 to 26.0.0 [#4584](https://github.com/ghostery/adblocker/pull/4584) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v2.1.2 (Thu Dec 05 2024)

#### :bug: Bug Fix

- Build(deps-dev): Bump mocha from 10.8.2 to 11.0.1 ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### :nut_and_bolt: Dependencies

- Build(deps-dev): Bump typescript-eslint from 8.16.0 to 8.17.0 [#4490](https://github.com/ghostery/adblocker/pull/4490) ([@dependabot[bot]](https://github.com/dependabot[bot]))
- Build(deps-dev): Bump mocha from 10.8.2 to 11.0.1 [#4489](https://github.com/ghostery/adblocker/pull/4489) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v2.1.0 (Wed Nov 20 2024)

#### :rocket: New Feature

- feat: Optional support for native :has pseudo classes [#4455](https://github.com/ghostery/adblocker/pull/4455) ([@chrmod](https://github.com/chrmod))

#### :bug: Bug Fix

- Remove "branch=master" ([@regseb](https://github.com/regseb))
- docs: Fix build badges ([@regseb](https://github.com/regseb))

#### :memo: Documentation

- docs: Fix build badges [#4413](https://github.com/ghostery/adblocker/pull/4413) ([@regseb](https://github.com/regseb))

#### Authors: 2

- Krzysztof Modras ([@chrmod](https://github.com/chrmod))
- Sébastien Règne ([@regseb](https://github.com/regseb))

---

# v2.0.0 (Thu Oct 17 2024)

#### :boom: Breaking Change

- Rename from @cliqz/adblocker to @ghostery/adblocker [#4366](https://github.com/ghostery/adblocker/pull/4366) ([@chrmod](https://github.com/chrmod))

#### Authors: 1

- Krzysztof Modras ([@chrmod](https://github.com/chrmod))

---

# v1.34.0 (Wed Oct 16 2024)

#### :bug: Bug Fix

- Build(deps-dev): Bump @types/chai from 4.3.19 to 5.0.0 ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### :nut_and_bolt: Dependencies

- Build(deps-dev): Bump @types/chai from 4.3.19 to 5.0.0 [#4314](https://github.com/ghostery/adblocker/pull/4314) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v1.32.0 (Mon Aug 26 2024)

#### :nut_and_bolt: Dependencies

- Build(deps-dev): Bump jsdom from 24.1.1 to 25.0.0 [#4223](https://github.com/ghostery/adblocker/pull/4223) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v1.31.0 (Thu Aug 01 2024)

#### :nut_and_bolt: Dependencies

- Build(deps-dev): Bump @types/node from 20.14.12 to 22.0.2 [#4166](https://github.com/ghostery/adblocker/pull/4166) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v1.29.0 (Wed Jul 17 2024)

#### :house: Internal

- Replace Cliqz references with Ghostery [#4095](https://github.com/ghostery/adblocker/pull/4095) ([@chrmod](https://github.com/chrmod))
- Update ESLint configuration for test files [#4102](https://github.com/ghostery/adblocker/pull/4102) ([@seia-soto](https://github.com/seia-soto))
- tsx to run typescript [#4098](https://github.com/ghostery/adblocker/pull/4098) ([@chrmod](https://github.com/chrmod))

#### :nut_and_bolt: Dependencies

- Build(deps-dev): Bump rimraf from 5.0.8 to 6.0.1 [#4078](https://github.com/ghostery/adblocker/pull/4078) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 3

- [@dependabot[bot]](https://github.com/dependabot[bot])
- HoJeong Go ([@seia-soto](https://github.com/seia-soto))
- Krzysztof Modras ([@chrmod](https://github.com/chrmod))

---

# v1.28.1 (Mon Jul 15 2024)

#### :bug: Bug Fix

- Simplify build with tshy [#4079](https://github.com/ghostery/adblocker/pull/4079) ([@chrmod](https://github.com/chrmod) [@seia-soto](https://github.com/seia-soto))

#### Authors: 2

- HoJeong Go ([@seia-soto](https://github.com/seia-soto))
- Krzysztof Modras ([@chrmod](https://github.com/chrmod))

---

# v1.28.0 (Tue Jul 09 2024)

#### :nut_and_bolt: Dependencies

- Update typescript [#4053](https://github.com/ghostery/adblocker/pull/4053) ([@chrmod](https://github.com/chrmod))

#### Authors: 1

- Krzysztof Modras ([@chrmod](https://github.com/chrmod))

---

# v1.27.11 (Mon Jun 10 2024)

#### :nut_and_bolt: Dependencies

- Build(deps-dev): Bump nyc from 15.1.0 to 17.0.0 [#4015](https://github.com/ghostery/adblocker/pull/4015) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v1.27.8 (Thu Jun 06 2024)

#### :bug: Bug Fix

- Bump version to: v1.27.7 \[skip ci\] [#4005](https://github.com/ghostery/adblocker/pull/4005) ([@adblocker-bot](https://github.com/adblocker-bot))
- Update CHANGELOG.md \[skip ci\] ([@adblocker-bot](https://github.com/adblocker-bot))

#### :nail_care: Polish

- Rename cliqz-oss to ghostery [#3986](https://github.com/ghostery/adblocker/pull/3986) ([@chrmod](https://github.com/chrmod))

#### ⚠️ Pushed to `master`

- Build system: update rollup plugins ([@chrmod](https://github.com/chrmod))

#### :house: Internal

- ESLint update [#3977](https://github.com/ghostery/adblocker/pull/3977) ([@chrmod](https://github.com/chrmod))
- ESM modules [#3924](https://github.com/ghostery/adblocker/pull/3924) ([@chrmod](https://github.com/chrmod))

#### Authors: 2

- Adblocker Bot ([@adblocker-bot](https://github.com/adblocker-bot))
- Krzysztof Modras ([@chrmod](https://github.com/chrmod))

---

# v1.27.4 (Wed Jun 05 2024)

#### :nail_care: Polish

- Rename cliqz-oss to ghostery [#3986](https://github.com/ghostery/adblocker/pull/3986) ([@chrmod](https://github.com/chrmod))

#### ⚠️ Pushed to `master`

- Build system: update rollup plugins ([@chrmod](https://github.com/chrmod))

#### :house: Internal

- ESLint update [#3977](https://github.com/ghostery/adblocker/pull/3977) ([@chrmod](https://github.com/chrmod))
- ESM modules [#3924](https://github.com/ghostery/adblocker/pull/3924) ([@chrmod](https://github.com/chrmod))

#### Authors: 1

- Krzysztof Modras ([@chrmod](https://github.com/chrmod))

---

# v1.26.16 (Thu Feb 22 2024)

#### :nut_and_bolt: Dependencies

- Build(deps-dev): Bump jsdom from 23.2.0 to 24.0.0 [#3728](https://github.com/ghostery/adblocker/pull/3728) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v1.26.13 (Tue Jan 09 2024)

#### :nut_and_bolt: Dependencies

- Build(deps-dev): Bump jsdom from 22.1.0 to 23.0.1 [#3633](https://github.com/ghostery/adblocker/pull/3633) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v1.26.8 (Mon Oct 09 2023)

#### :house: Internal

- Update local assets [#3472](https://github.com/ghostery/adblocker/pull/3472) (ghostery-adblocker-bot@users.noreply.github.com [@remusao](https://github.com/remusao) [@ghostery-adblocker-bot[bot]](https://github.com/ghostery-adblocker-bot[bot]))
- Replace tslint with eslint [#3450](https://github.com/ghostery/adblocker/pull/3450) ([@chrmod](https://github.com/chrmod))

#### Authors: 4

- [@ghostery-adblocker-bot[bot]](https://github.com/ghostery-adblocker-bot[bot])
- Ghostery Adblocker Bot (ghostery-adblocker-bot@users.noreply.github.com)
- Krzysztof Modras ([@chrmod](https://github.com/chrmod))
- Rémi ([@remusao](https://github.com/remusao))

---

# v1.26.7 (Mon Sep 18 2023)

#### :bug: Bug Fix

- Attempt to fix publishing workflow [#3443](https://github.com/ghostery/adblocker/pull/3443) ([@remusao](https://github.com/remusao) [@chrmod](https://github.com/chrmod))

#### :house: Internal

- Updates of dependencies and CI [#3353](https://github.com/ghostery/adblocker/pull/3353) ([@remusao](https://github.com/remusao))

#### Authors: 2

- Krzysztof Modras ([@chrmod](https://github.com/chrmod))
- Rémi ([@remusao](https://github.com/remusao))

---

# v1.26.6 (Fri Jun 02 2023)

#### :nut_and_bolt: Dependencies

- Build(deps-dev): Bump typescript from 4.9.5 to 5.0.4 [#3180](https://github.com/ghostery/adblocker/pull/3180) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v1.26.2 (Thu Mar 02 2023)

#### :nut_and_bolt: Dependencies

- Build(deps-dev): Bump @types/jsdom from 20.0.1 to 21.1.0 [#3086](https://github.com/ghostery/adblocker/pull/3086) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v1.26.0 (Wed Feb 22 2023)

#### :nut_and_bolt: Dependencies

- Build(deps-dev): Bump jsdom from 20.0.3 to 21.0.0 [#3005](https://github.com/ghostery/adblocker/pull/3005) ([@dependabot[bot]](https://github.com/dependabot[bot]))
- Build(deps-dev): Bump rimraf from 3.0.2 to 4.0.7 [#3018](https://github.com/ghostery/adblocker/pull/3018) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v1.25.2 (Mon Jan 16 2023)

#### :house: Internal

- Update deps and CI [#2889](https://github.com/ghostery/adblocker/pull/2889) ([@remusao](https://github.com/remusao))

#### :nut_and_bolt: Dependencies

- Build(deps-dev): Bump @types/mocha from 9.1.1 to 10.0.0 [#2843](https://github.com/ghostery/adblocker/pull/2843) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 2

- [@dependabot[bot]](https://github.com/dependabot[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v1.24.0 (Fri Aug 26 2022)

#### :nut_and_bolt: Dependencies

- Build(deps-dev): Bump jsdom and @types/jsdom [#2766](https://github.com/ghostery/adblocker/pull/2766) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v1.23.9 (Fri Aug 19 2022)

#### :nut_and_bolt: Dependencies

- Build(deps-dev): Bump @types/node from 17.0.41 to 18.0.0 [#2664](https://github.com/ghostery/adblocker/pull/2664) ([@dependabot[bot]](https://github.com/dependabot[bot]))
- Build(deps-dev): Bump mocha from 9.2.2 to 10.0.0 [#2582](https://github.com/ghostery/adblocker/pull/2582) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v1.23.4 (Mon Jan 17 2022)

#### :nut_and_bolt: Dependencies

- Bump @types/node from 16.11.10 to 17.0.8 [#2350](https://github.com/ghostery/adblocker/pull/2350) ([@dependabot[bot]](https://github.com/dependabot[bot]))
- Bump jsdom from 18.1.1 to 19.0.0 [#2356](https://github.com/ghostery/adblocker/pull/2356) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v1.23.0 (Mon Oct 18 2021)

#### :nut_and_bolt: Dependencies

- Bump jsdom from 17.0.0 to 18.0.0 [#2267](https://github.com/ghostery/adblocker/pull/2267) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v1.22.7 (Wed Sep 22 2021)

#### :house: Internal

- Bump typescript [#2243](https://github.com/ghostery/adblocker/pull/2243) ([@remusao](https://github.com/remusao))

#### :nut_and_bolt: Dependencies

- Bump @types/node from 15.6.1 to 16.9.6 [#2235](https://github.com/ghostery/adblocker/pull/2235) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 2

- [@dependabot[bot]](https://github.com/dependabot[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v1.22.5 (Wed Aug 25 2021)

#### :nut_and_bolt: Dependencies

- Bump jsdom from 16.7.0 to 17.0.0 [#2175](https://github.com/ghostery/adblocker/pull/2175) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v1.22.3 (Thu Jul 29 2021)

#### :nut_and_bolt: Dependencies

- Bump @types/mocha from 8.2.3 to 9.0.0 [#2062](https://github.com/ghostery/adblocker/pull/2062) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v1.22.2 (Sun Jun 20 2021)

#### :nut_and_bolt: Dependencies

- Bump mocha from 8.4.0 to 9.0.0 [#1989](https://github.com/ghostery/adblocker/pull/1989) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v1.21.0 (Sun May 30 2021)

#### :rocket: New Feature

- Bump Electron to v13.x and Puppeteer to v9.x [#1967](https://github.com/ghostery/adblocker/pull/1967) ([@remusao](https://github.com/remusao))

#### :house: Internal

- Bump lock file to fix some security issue [#1922](https://github.com/ghostery/adblocker/pull/1922) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v1.20.5 (Tue May 04 2021)

#### :bug: Bug Fix

- build(deps-dev): bump @types/node from 14.14.41 to 15.0.0 ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### :nut_and_bolt: Dependencies

- build(deps-dev): bump auto from 10.25.1 to 10.25.2 [#1892](https://github.com/ghostery/adblocker/pull/1892) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))
- build(deps): bump tldts-experimental from 5.7.29 to 5.7.30 [#1889](https://github.com/ghostery/adblocker/pull/1889) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))
- build(deps-dev): bump @types/node from 14.14.41 to 15.0.0 [#1888](https://github.com/ghostery/adblocker/pull/1888) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 1

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])

---

# v1.20.0 (Thu Jan 21 2021)

### Release Notes

#### Initial support for extended CSS selectors (a.k.a. procedural filters) ([#1574](https://github.com/ghostery/adblocker/pull/1574))

Add initial support for extended CSS selectors (a.k.a. procedural filters) as well as the `:remove()` modifier for element hiding rules (note: the already supported `:style` modified now also works with extended CSS selectors). The following new pseudo-classes are implemented: `:has`, `:has-text` (both string and RegExp literals), and `:not` (whenever its argument is also an extended selector, otherwise fallback to native implementation).

Caveats:
* Loading of extended css filters is disabled by default and needs to be toggled using the `loadExtendedSelectors` option while [initializing the blocker instance](https://github.com/ghostery/adblocker/blob/3361723138f40c3cb96b4c6e611f2b030f75d891/packages/adblocker-webextension-example/background.ts#L61).
* These news selectors are currently only supported by `WebExtensionBlocker` (support for Puppeteer, Electron and Playwright is not planned at this time but help from the community would be greatly appreciated).

Miscellaneous changes:
* Removal of unused `injectCSSRule` helper.
* Replace Closure compiler by Terser.

---

#### :rocket: New Feature

- Initial support for extended CSS selectors (a.k.a. procedural filters) [#1574](https://github.com/ghostery/adblocker/pull/1574) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))
